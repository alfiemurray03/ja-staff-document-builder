# JA Staff Document Builder

Private document creation platform for authorised personnel of JA Group Services Ltd and JSDS Group Ltd.

The application preserves the existing guided letter, email, policy, form, invoice, checklist, report, minutes, proposal and contract builders, live previews, rich editing, drafts, saved documents, folders, printing, downloads, templates and audit features.

## Access model

Access is through a single-tenant Microsoft Entra workforce application. Public registration and local-password authentication are retired. Assign one of these Entra application roles to every authorised user: `System Administrator`, `Company Director`, `Staff Member`, or `Read Only`. A valid Microsoft identity without one of these roles is denied; missing roles never imply administrator access.

Create the roles in **App registrations > App roles**, expose a Web redirect URI matching `OIDC_REDIRECT_URI`, create a client secret, and grant assignments through the Enterprise Application. Keep all credentials outside Git.

## Local setup

1. Install Node.js 22 and MySQL 8.
2. Copy `env.example` to `.env` and supply database and Entra values.
3. Run `npm install`.
4. Run the existing Drizzle migrations with `npx tsx src/server/db/migrate.ts` (or allow server startup to run its idempotent migration runner).
5. Run `npm run dev`.

Useful commands: `npm run type-check`, `npm test`, `npm run lint`, `npm run build`, and `npm run preview`.

## Production

Run `npm run build`, set `NODE_ENV=production`, provide the variables below through the hosting platform's secret store, and run the generated Express server bundle. Terminate TLS at the application or a trusted reverse proxy. Production session cookies are Secure, HTTP-only and SameSite=Lax.

## Environment variables

- `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASS`, `DB_NAME`: MySQL connection.
- `OIDC_AUTHORITY`: must be `https://login.microsoftonline.com`.
- `OIDC_TENANT_ID`, `OIDC_CLIENT_ID`, `OIDC_CLIENT_SECRET`: Entra workforce app values.
- `OIDC_REDIRECT_URI`: exact registered callback URI.
- `OIDC_SESSION_SECRET`: at least 32 random bytes.
- `APP_URL`, `PORT`, `HOST`, `NODE_ENV`: runtime configuration.
- `VITE_APP_NAME`, `VITE_PUBLIC_URL`, `VITE_API_URL`: non-secret browser configuration.

Never prefix secrets with `VITE_`; Vite-prefixed values are bundled for browsers.

## Legacy data

Commercial, Stripe, affiliate, reseller and password-authentication tables remain in the schema to avoid destructive migration risk. Their public APIs are disabled and normal builder authorisation does not use subscription plans. Review and archive legacy data under an approved retention schedule before any later schema-removal migration.
